import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import {
  Calendar,
  FileSpreadsheet,
  FileText,
  Folder,
  LayoutGrid,
  MessageSquare,
  Plus,
  Presentation,
  Send,
  Users,
  type LucideIcon,
} from 'lucide-react'
import { Bar, Collapse, Scroll, Stage, type Act, type Point } from '../../kit'
import '../agent-doc-edit/agent-doc-edit.css'
import './feishu-material-collection.css'

// Interactive material collection into global doubao (t35u / t36u).
// Default: once-play motion + blue arrow cursor + restrained ripples.
// ?view=ppt|im — static filled stills for film QA.

type View = 'ppt' | 'im'
type Kind = 'doc' | 'sheet' | 'ppt' | 'note'

type Att = { id: string; name: string; kind: Kind }
type Ghost = { on: boolean; dropped: boolean; off: Point; at: Point; ids: string[] }

type S = {
  view: View
  atts: Att[]
  prompt: string
  selected: string[]
  ghost: Ghost
}

const PPT_TITLE = 'Project Review Report'
const PROMPT = 'Create a project review deck'
const GROUP = 'CCM Design'

const CLOUD: Att[] = [
  { id: 'c1', name: 'Project plan', kind: 'doc' },
  { id: 'c2', name: 'Data stats', kind: 'sheet' },
  { id: 'c3', name: 'Prior review.pptx', kind: 'ppt' },
]

const PPT_ATTS: Att[] = [...CLOUD]

const IM_ATTS: Att[] = [
  ...PPT_ATTS,
  { id: 'm1', name: 'Progress tracker', kind: 'sheet' },
  { id: 'm2', name: 'Group decisions', kind: 'note' },
]

/** Stable chip slots — Collapse open per id so rows grow, never pop */
const CHIP_SLOTS: Att[] = IM_ATTS

const emptyGhost: Ghost = { on: false, dropped: false, off: { x: 0, y: 0 }, at: { x: 0, y: 0 }, ids: [] }

function detectStaticView(): View | null {
  if (typeof window === 'undefined') return null
  const q = new URLSearchParams(window.location.search)
  if (q.get('view') === 'im' || q.get('static') === 'im') return 'im'
  if (q.get('view') === 'ppt' || q.get('static') === 'ppt') return 'ppt'
  return null
}

const _static = detectStaticView()
const isStatic = _static !== null

const initial: S = isStatic
  ? {
      view: _static!,
      atts: _static === 'im' ? IM_ATTS : PPT_ATTS,
      prompt: PROMPT,
      selected: [],
      ghost: emptyGhost,
    }
  : {
      view: 'ppt',
      atts: [],
      prompt: '',
      selected: [],
      ghost: emptyGhost,
    }

/** Poster tells the collected payoff on its own. */
const poster: S = {
  view: 'im',
  atts: IM_ATTS,
  prompt: PROMPT,
  selected: [],
  ghost: emptyGhost,
}

async function scriptStatic(a: Act<S>) {
  a.mark('hold')
  await a.wait(3_600_000)
}

async function scriptMotion(a: Act<S>) {
  // 1. Empty composer — cursor rests near cloud files
  a.mark('empty')
  await a.move({ at: 'cloud-c1', x: 0.55, y: 0.55 })
  await a.wait(700)

  // 2. Multi-select three Docs files (ripple each click)
  a.mark('select-cloud')
  for (const f of CLOUD) {
    await a.click(`cloud-${f.id}`)
    await a.set((s) => ({
      selected: s.selected.includes(f.id) ? s.selected : [...s.selected, f.id],
    }))
    await a.wait(150)
  }

  // Drag-start press: click for kit ripple, then carry the stack
  a.mark('drag-cloud')
  await a.click('cloud-c2')
  await a.wait(70)
  const src = a.rect('cloud-c2')
  const grab = { x: src.x + src.width * 0.45, y: src.y + src.height * 0.5 }
  const off = { x: grab.x - src.x, y: grab.y - src.y }
  const drop = a.rect('composer')
  const dropAt = { x: drop.x + drop.width * 0.48, y: drop.y + drop.height * 0.42 }
  const cloudIds = CLOUD.map((c) => c.id)
  await a.drag(
    dropAt,
    (at) => {
      a.put({ ghost: { on: true, dropped: false, off, at, ids: cloudIds } })
    },
    { duration: 1150, cursor: 'preserve' },
  )

  a.mark('drop-cloud')
  await a.set({
    atts: PPT_ATTS,
    selected: [],
    ghost: { on: true, dropped: true, off, at: dropAt, ids: cloudIds },
  })
  await a.wait(320)
  await a.set({ ghost: emptyGhost })
  await a.wait(560)

  // 3. Nav to Messages — doubao stays mounted with chips
  a.mark('nav-im')
  await a.click('nav-msg')
  await a.set({ view: 'im' })
  await a.wait(650)

  // 4. Scroll thread, drag two chat materials
  a.mark('scroll-chat')
  await a.scroll('chat-stream', 'chat-concl', { offset: 36, duration: 720 })
  await a.wait(180)

  a.mark('drag-chat-file')
  await a.click('chat-file')
  await a.wait(60)
  const cf = a.rect('chat-file')
  const cfOff = { x: 22, y: 14 }
  const drop2 = a.rect('composer')
  const drop2At = { x: drop2.x + drop2.width * 0.5, y: drop2.y + drop2.height * 0.48 }
  await a.drag(
    drop2At,
    (at) => {
      a.put({ ghost: { on: true, dropped: false, off: cfOff, at, ids: ['m1'] } })
    },
    { duration: 980, cursor: 'preserve' },
  )
  await a.set((s) => ({
    atts: s.atts.some((x) => x.id === 'm1')
      ? s.atts
      : [...s.atts, { id: 'm1', name: 'Progress tracker', kind: 'sheet' as Kind }],
    ghost: { ...s.ghost, dropped: true },
  }))
  await a.wait(280)
  await a.set({ ghost: emptyGhost })
  await a.wait(420)

  a.mark('drag-chat-concl')
  await a.click('chat-concl')
  await a.wait(60)
  const drop3 = a.rect('composer')
  const drop3At = { x: drop3.x + drop3.width * 0.52, y: drop3.y + drop3.height * 0.5 }
  await a.drag(
    drop3At,
    (at) => {
      a.put({ ghost: { on: true, dropped: false, off: cfOff, at, ids: ['m2'] } })
    },
    { duration: 980, cursor: 'preserve' },
  )
  await a.set((s) => ({
    atts: s.atts.some((x) => x.id === 'm2')
      ? s.atts
      : [...s.atts, { id: 'm2', name: 'Group decisions', kind: 'note' as Kind }],
    ghost: { ...s.ghost, dropped: true },
  }))
  await a.wait(280)
  await a.set({ ghost: emptyGhost })
  await a.wait(480)

  // 5. Type prompt, hold ~3s, no send
  a.mark('type')
  await a.click('composer-input')
  await a.type('prompt', PROMPT, { interval: 40 })
  a.mark('hold')
  await a.wait(3_000)
}

function Glyph({ icon: Icon, size = 16 }: { icon: LucideIcon; size?: number }) {
  const box = size % 2 === 0 ? size + 2 : size + 1
  return (
    <span className="fs-i-slot" style={{ width: box, height: box }}>
      <Icon size={size} strokeWidth={1.7} className="fs-i" aria-hidden />
    </span>
  )
}

function Face({ letter, tone, size = 28 }: { letter?: string; tone: number; size?: number }) {
  return (
    <span className="fs-face" data-tone={tone} style={{ width: size, height: size, fontSize: Math.round(size * 0.38) }}>
      {letter || ''}
    </span>
  )
}

function FileGlyph({ kind, size = 15 }: { kind: Kind; size?: number }) {
  if (kind === 'sheet') return <FileSpreadsheet size={size} strokeWidth={1.75} className="fmc-ico" data-kind={kind} />
  if (kind === 'ppt') return <Presentation size={size} strokeWidth={1.75} className="fmc-ico" data-kind={kind} />
  if (kind === 'note') return <MessageSquare size={size} strokeWidth={1.75} className="fmc-ico" data-kind={kind} />
  return <FileText size={size} strokeWidth={1.75} className="fmc-ico" data-kind={kind} />
}

function Lights() {
  return (
    <span className="ss-window__lights" aria-hidden>
      <span className="ss-window__dot" />
      <span className="ss-window__dot" />
      <span className="ss-window__dot" />
    </span>
  )
}

const NAV: { id: string; icon: LucideIcon; label: string }[] = [
  { id: 'msg', icon: MessageSquare, label: 'Messages' },
  { id: 'cal', icon: Calendar, label: 'Calendar' },
  { id: 'docs', icon: FileText, label: 'Docs' },
  { id: 'apps', icon: LayoutGrid, label: 'Apps' },
  { id: 'people', icon: Users, label: 'People' },
]

export default function FeishuMaterialCollection() {
  return (
    <Stage<S>
      width={1180}
      height={640}
      compact={{ below: 720, width: 358, height: 320 }}
      initial={initial}
      poster={poster}
      script={isStatic ? scriptStatic : scriptMotion}
      play="once"
      className="fs fmc"
      fidelity="standard"
      accent="#3370ff"
      cursor={
        isStatic
          ? undefined
          : { style: 'arrow', ripple: true, at: { at: 'cloud-c1', x: 0.55, y: 0.55 }, idle: false }
      }
    >
      {(s, _rect, layout) => <App s={s} compact={layout === 'compact'} />}
    </Stage>
  )
}

function App({ s, compact }: { s: S; compact: boolean }) {
  const [manual, setManual] = useState<View | null>(null)
  useEffect(() => {
    setManual(null)
  }, [s.view])
  const view: View = manual ?? s.view
  const isPpt = view === 'ppt'
  const atts = s.atts
  const prompt = s.prompt
  const title = isPpt ? PPT_TITLE : 'Messages'
  const lifted = s.ghost.on && !s.ghost.dropped

  return (
    <div
      className="ss-window fs-win"
      data-compact={compact || undefined}
      data-view={view}
      role="application"
      aria-label={title}
    >
      <div className="fs-shell" data-crop>
        <div className="fs-main">
          <div className="fs-main__bar">
            <Lights />
            <span className="fs-main__title">{title}</span>
          </div>
          <div className="fs-main__body">
            <Nav view={view} onMessages={() => setManual('im')} onDocs={() => setManual('ppt')} />
            <div className="fs-work">
              <div className="fs-pane fs-pane--ppt" data-on={isPpt || undefined} aria-hidden={!isPpt}>
                {!compact && (
                  <CloudTree selected={s.selected} liftedIds={lifted ? s.ghost.ids : []} />
                )}
                <PptCanvas />
              </div>
              <div className="fs-pane fs-pane--im" data-on={!isPpt || undefined} aria-hidden={isPpt}>
                {!compact && <Feed />}
                {!compact && <Chat liftedIds={lifted ? s.ghost.ids : []} />}
              </div>
            </div>
          </div>
        </div>
        <DoubaoRail atts={atts} prompt={prompt} />
      </div>
      <DragGhost ghost={s.ghost} />
    </div>
  )
}

function Nav({
  view,
  onMessages,
  onDocs,
}: {
  view: View
  onMessages: () => void
  onDocs: () => void
}) {
  const on = view === 'ppt' ? 'docs' : 'msg'
  return (
    <aside className="fs-nav" data-crop>
      <Face letter="H" tone={1} size={28} />
      <div className="fs-nav__list">
        {NAV.map((item) => {
          const clickable = item.id === 'msg' || item.id === 'docs'
          return (
            <button
              key={item.id}
              type="button"
              className="fs-nav__item"
              data-on={on === item.id || undefined}
              data-target={item.id === 'msg' ? 'nav-msg' : item.id === 'docs' ? 'nav-docs' : undefined}
              data-cursor={clickable ? 'pointer' : undefined}
              aria-label={item.label}
              onClick={item.id === 'msg' ? onMessages : item.id === 'docs' ? onDocs : undefined}
              tabIndex={clickable ? 0 : -1}
            >
              <Glyph icon={item.icon} size={16} />
            </button>
          )
        })}
      </div>
    </aside>
  )
}

function CloudTree({ selected, liftedIds }: { selected: string[]; liftedIds: string[] }) {
  const folders = [
    { key: 'f1', w: '58%' },
    { key: 'f2', w: '64%' },
    { key: 'f3', w: '48%' },
    { key: 'f4', w: '52%' },
  ]
  return (
    <aside className="fmc-cloud" data-crop>
      <div className="fmc-cloud__head">Docs</div>
      <div className="fmc-cloud__sec">
        {folders.map((f) => (
          <div key={f.key} className="fmc-cloud__row">
            <Folder size={14} strokeWidth={1.6} className="fmc-cloud__ico" />
            <Bar w={f.w} h={6} r={3} tone={2} />
          </div>
        ))}
      </div>
      <div className="fmc-cloud__sec">
        <div className="fmc-cloud__sec-lab">Project review</div>
        {CLOUD.map((f) => (
          <div
            key={f.id}
            className="fmc-cloud__file"
            data-kind={f.kind}
            data-on={selected.includes(f.id) || undefined}
            data-lifted={liftedIds.includes(f.id) || undefined}
            data-target={`cloud-${f.id}`}
            data-cursor="pointer"
          >
            <span className="fmc-cloud__glyph" data-kind={f.kind}>
              <FileGlyph kind={f.kind} size={14} />
            </span>
            <span className="fmc-cloud__name">{f.name}</span>
          </div>
        ))}
        {[0, 1, 2].map((i) => (
          <div key={i} className="fmc-cloud__file" aria-hidden>
            <span className="fmc-cloud__glyph" data-kind="doc">
              <FileText size={14} strokeWidth={1.75} className="fmc-ico" data-kind="doc" />
            </span>
            <Bar w={`${52 + i * 10}%`} h={6} r={3} tone={2} />
          </div>
        ))}
      </div>
    </aside>
  )
}

function PptCanvas() {
  return (
    <section className="fmc-ppt" data-target="ppt-body" data-crop>
      <div className="fmc-ppt__toolbar">
        <Bar w={40} h={6} r={3} tone={2} />
        <Bar w={40} h={6} r={3} tone={2} />
        <Bar w={56} h={6} r={3} tone={2} />
        <span className="fmc-ppt__spacer" />
        <Bar w={72} h={6} r={3} tone={2} />
      </div>
      <div className="fmc-ppt__stage">
        <div className="fmc-ppt__rail">
          {[1, 2, 3, 4].map((n) => (
            <div key={n} className="fmc-ppt__thumb" data-on={n === 1 || undefined}>
              <span className="fmc-ppt__num">{n}</span>
              <div className="fmc-ppt__mini">
                <Bar w="70%" h={4} r={2} tone={2} />
                <Bar w="48%" h={4} r={2} tone={2} />
              </div>
            </div>
          ))}
        </div>
        <div className="fmc-ppt__canvas">
          <div className="fmc-ppt__slide">
            <div className="fmc-ppt__title">{PPT_TITLE}</div>
            <div className="fmc-ppt__sub">Q3 milestones · materials for doubao</div>
            <div className="fmc-ppt__sec">
              <div className="fmc-ppt__sec-lab">Goals</div>
              <Bar w="78%" h={6} r={3} tone={2} />
              <Bar w="62%" h={6} r={3} tone={2} />
            </div>
            <div className="fmc-ppt__sec">
              <div className="fmc-ppt__sec-lab">Key metrics</div>
              <Bar w="70%" h={6} r={3} tone={2} />
              <Bar w="54%" h={6} r={3} tone={2} />
            </div>
            <div className="fmc-ppt__sec">
              <div className="fmc-ppt__sec-lab">Next steps</div>
              <Bar w="66%" h={6} r={3} tone={2} />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function Feed() {
  return (
    <section className="fs-feed">
      <div className="fs-feed__head">Messages</div>
      <div className="fs-feed__row" data-on>
        <Face letter="C" tone={2} size={32} />
        <div className="fs-feed__meta">
          <div className="fs-feed__name">{GROUP}</div>
          <Bar w="72%" h={6} r={3} tone={2} />
        </div>
      </div>
      {[3, 4, 3, 4, 3].map((tone, i) => (
        <div key={i} className="fs-feed__row">
          <Face tone={tone === 3 ? 3 : 4} size={32} />
          <div className="fs-feed__meta">
            <Bar w={`${58 + (i % 3) * 10}%`} h={6} r={3} tone={2} />
            <Bar w={`${42 + (i % 2) * 14}%`} h={5} r={2.5} tone={2} />
          </div>
        </div>
      ))}
    </section>
  )
}

function Chat({ liftedIds }: { liftedIds: string[] }) {
  return (
    <section className="fs-chat" data-crop>
      <header className="fs-chat__head">
        <Face letter="C" tone={2} size={22} />
        <span>{GROUP}</span>
      </header>
      <Scroll name="chat-stream" className="fs-chat__stream fmc-chat__stream" bar="overlay">
        <div className="fs-msg">
          <Face letter="L" tone={5} size={28} />
          <div className="fs-bubble">
            <Bar w={148} h={6} r={3} tone={2} />
            <Bar w={112} h={6} r={3} tone={2} />
          </div>
        </div>
        <div className="fs-msg" data-mine>
          <div className="fs-bubble" data-mine>
            <Bar w={96} h={6} r={3} tone={2} />
          </div>
        </div>
        <div
          className="fs-msg"
          data-target="chat-file"
          data-cursor="pointer"
          data-lifted={liftedIds.includes('m1') || undefined}
        >
          <Face letter="M" tone={5} size={28} />
          <div className="fs-bubble fmc-bubble-file">
            <span className="fmc-bubble-file__row">
              <FileGlyph kind="sheet" size={13} />
              <span className="fmc-bubble-file__name">Progress tracker</span>
            </span>
            <Bar w="62%" h={5} r={2.5} tone={2} />
          </div>
        </div>
        <div
          className="fs-msg"
          data-target="chat-concl"
          data-cursor="pointer"
          data-lifted={liftedIds.includes('m2') || undefined}
        >
          <Face letter="K" tone={4} size={28} />
          <div className="fs-bubble">
            <span className="fmc-bubble-text">Group decisions</span>
            <Bar w="78%" h={5} r={2.5} tone={2} />
            <Bar w="54%" h={5} r={2.5} tone={2} />
          </div>
        </div>
        <div className="fs-msg">
          <Face letter="A" tone={4} size={28} />
          <div className="fs-bubble">
            <Bar w={132} h={6} r={3} tone={2} />
            <Bar w={88} h={6} r={3} tone={2} />
          </div>
        </div>
        {/* Filler so scroll has room */}
        <div className="fs-msg" aria-hidden>
          <Face tone={3} size={28} />
          <div className="fs-bubble">
            <Bar w={120} h={6} r={3} tone={2} />
            <Bar w={90} h={6} r={3} tone={2} />
          </div>
        </div>
      </Scroll>
    </section>
  )
}

function DoubaoRail({ atts, prompt }: { atts: Att[]; prompt: string }) {
  const suggestionWidths = ['72%', '92%', '58%']
  return (
    <aside className="fs-ai fmc-ai" data-target="doubao" aria-label="doubao">
      <header className="fs-ai__head">doubao</header>
      <div className="fmc-ai__body">
        <div className="fmc-ai__agenda">What&apos;s on your agenda today?</div>
        <div className="fmc-ai__spacer" aria-hidden />
        <div className="fmc-ai__suggestions" aria-hidden>
          {suggestionWidths.map((w, i) => (
            <div key={i} className="fmc-ai__suggest" style={{ width: w }}>
              <Bar w="70%" h={6} r={3} tone={2} />
            </div>
          ))}
        </div>
      </div>
      <div className="fmc-composer" data-target="composer" data-drop>
        <div className="fmc-chips">
          {CHIP_SLOTS.map((a) => (
            <Collapse key={a.id} open={atts.some((x) => x.id === a.id)} reveal="clip">
              <span className="fmc-chip" data-kind={a.kind}>
                <FileGlyph kind={a.kind} size={12} />
                <span className="fmc-chip__name">{a.name}</span>
              </span>
            </Collapse>
          ))}
        </div>
        <div className="fmc-composer__row">
          <Glyph icon={Plus} size={14} />
          <span
            className="fmc-composer__text"
            data-target="composer-input"
            data-cursor="ibeam"
            data-empty={!prompt || undefined}
          >
            {prompt || 'Ask doubao…'}
          </span>
          <span className="fmc-composer__send" aria-hidden>
            <Send size={14} strokeWidth={1.75} />
          </span>
        </div>
      </div>
    </aside>
  )
}

/** Drag image rides with the arrow; chip stack mirrors what is carried. */
function DragGhost({ ghost }: { ghost: Ghost }) {
  const ref = useRef<HTMLDivElement>(null)
  const following = ghost.on && !ghost.dropped
  const { x: ox, y: oy } = ghost.off
  const { x, y } = ghost.at
  const items = ghost.ids
    .map((id) => CLOUD.find((c) => c.id === id) || IM_ATTS.find((c) => c.id === id))
    .filter(Boolean) as Att[]

  useLayoutEffect(() => {
    const root = ref.current?.closest<HTMLElement>('.ss-stage')
    let next: HTMLElement | null = null
    if (following && root) {
      const box = root.getBoundingClientRect()
      const scale = box.width / root.offsetWidth || 1
      const hit =
        document.elementFromPoint(box.left + x * scale, box.top + y * scale)?.closest<HTMLElement>('[data-drop]') ??
        null
      if (hit && root.contains(hit)) next = hit
    }
    const prev = ref.current?.dataset.overEl
    if (prev) {
      const el = root?.querySelector<HTMLElement>(`[data-target="${prev}"]`)
      el?.removeAttribute('data-over')
    }
    if (next) {
      next.setAttribute('data-over', '')
      if (ref.current) ref.current.dataset.overEl = next.getAttribute('data-target') || ''
    } else if (ref.current) {
      delete ref.current.dataset.overEl
    }
  }, [following, x, y])

  return (
    <div
      ref={ref}
      className="fmc-drag"
      data-show={following || undefined}
      data-dropped={ghost.dropped || undefined}
      style={{ transform: `translate(${x - ox}px, ${y - oy}px)` }}
      aria-hidden
    >
      <div className="fmc-drag__stack" style={{ transformOrigin: `${ox}px ${oy}px` }}>
        {items.slice(0, 3).map((it, i) => (
          <span key={it.id} className="fmc-drag__chip" data-kind={it.kind} style={{ ['--i' as string]: i }}>
            <FileGlyph kind={it.kind} size={11} />
            <span>{it.name}</span>
          </span>
        ))}
      </div>
    </div>
  )
}
