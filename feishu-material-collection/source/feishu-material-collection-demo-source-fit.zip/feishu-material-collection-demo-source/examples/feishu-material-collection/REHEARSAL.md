# REHEARSAL — feishu-material-collection (interactive · t35u / t36u / t37u)

## Gate (1280 · `.ss-fit`)
- **Result:** `rehearsal passed` (design 1:1 under `__ssVerification`)
- Contain live fit does not change Stage design size; film still forces `--fs-scale: 1`.

## Viewport fit QA (t37u · file:// / portable)
Contain `min(1, w/1180, h/640)` — full 1180×640 stage visible; no L/R clip.

| Viewport | Expected scale | Checks |
|---|---|---|
| 944×630 (user screenshot) | ≈0.800 | nav + AI heading + chips + composer + Replay in view |
| 1024×700 | ≈0.868 | same; sand margins |
| 1280×800 | 1.000 | design 1:1, sand gutters |
| 1440×900 | 1.000 | centered on sand |
| 390×844 narrow | ≈0.331 | whole frame fit, no L/R clip (no phone redesign) |

ResizeObserver on `documentElement` + `resize` updates `--fs-scale`; kit `drawnScale` keeps cursor/ghost/drop consistent.

## Cursor QA
- Kit arrow visible throughout motion; ink `#3370ff`
- Ripple on cloud selects, drag-start presses, nav, composer click
- Ghost stack tracks cursor during drags; fades on drop
- `idle: false` — no restless motion

## Polish applied
- Per-chip `Collapse` (no 5th-chip height jump)
- Ghost opacity fade in/out
- Pane crossfade without translateY pop
- **t37u:** cover→contain portable/offline fit (nav/AI no longer clipped at 944×630)

## Known inconclusive (not gate-failing)
- Pane/scroll “appears” false positives; title/type content swaps (manual)
- Lopsided cloud rows / tight bubble lines (approved static-v3 chrome)
- Favicon 404 incomplete-only
- `--width 390`: framing gate still fails for desktop window — optional compact redesign out of this pass; live contain still shows whole stage

## Deliverables
| Artifact | Path |
|---|---|
| Offline HTML (fit) | `/workspace/feishu-material-collection/exports/feishu-material-collection-demo-fit.html` |
| Source ZIP (fit) | `/workspace/feishu-material-collection/exports/feishu-material-collection-demo-source-fit.zip` |
| Fit QA shots | `/workspace/feishu-material-collection/exports/fit-qa/` |
| Film pack | `/workspace/feishu-material-collection/exports/film/` |
