# PLAN — feishu-material-collection (interactive demo · t35u / t36u)

## Medium
Animation, `play="once"` + Replay remount. Design 1180×640 (compact 358×320). Sand `#EEEDEB`. Film via portable `:4613` / `?capture=feishu-material-collection`. Static stills still available at `?view=ppt|im`.

## Look
Approved static-v3 Feishu shell (t34u): full-height doubao rail, no header divider, unified light-blue chips, agenda + 3 skeleton suggestions, English, lowercase `doubao`. Accent `#3370ff`.

## Cursor (t36u · kit norm)
`cursor={{ style: 'arrow', ripple: true }}` — stageshow illustrated arrow, blue ink (`--ss-cursor-ink: #3370ff`), restrained blue ripple on meaningful `a.click` / drag-start press (select-then-drag). Align to measured `data-target` rects; ghost follows cursor during drag. No bounce, no idle fidget.

## Story (~15–16s, 5 beats)
1. **Empty** — composer empty; cursor rests near cloud files (~0.8s).
2. **Cloud collect** — click-select three Docs files (ripple each), drag stack into doubao composer; three chips land (~4s).
3. **Nav IM** — click Messages; shell swaps to IM; doubao stays mounted with chips (~1.2s).
4. **Chat collect** — scroll thread, drag Progress tracker + Group decisions into composer; five chips (~3.5s).
5. **Prompt hold** — click composer, type `Create a project review deck`, hold ~3s, no send. Once ends; Replay remounts.

## Framing
Unchanged from static-v3: Window 1132×820 bleed bottom; L/T/R gutters; doubao flush top.

## Viewport fit (t37u)
Portable + offline root uses **contain** scale-to-fit of the 1180×640 stage:
`scale = min(1, vw/1180, vh/640)` via CSS `--fs-scale` on `.ss-fit` (centered).
Never cover/`Math.max`, never fixed scale 1 that clips sides, never stretch.
Sand `#EEEDEB` may extend into leftover viewport; product window stays whole.
`ResizeObserver` + `resize` remeasure `--fs-scale`. Kit `drawnScale` keeps cursor/ghost/drop aligned.
Film/`__ssVerification` forces `--fs-scale: 1` so gate stills stay 1:1 design.
Prioritize full nav rail, AI heading, 5 chips, composer, Replay over filling the crop.

## Out of scope
Send, real upload, CJK, redesign of approved chrome.
