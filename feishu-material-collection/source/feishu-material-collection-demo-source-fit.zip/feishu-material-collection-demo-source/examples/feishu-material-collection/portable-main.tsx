import { useState } from 'react'
import { createRoot } from 'react-dom/client'
import FeishuMaterialCollection from './index'
import '../../kit/stageshow.css'

function Shell() {
  const [k, setK] = useState(0)
  return (
    <div id="example" className="fs-portable">
      <FeishuMaterialCollection key={k} />
      <button type="button" className="fmc-replay" onClick={() => setK((n) => n + 1)} aria-label="Replay">
        Replay
      </button>
    </div>
  )
}

const root = document.getElementById('root')
if (root) createRoot(root).render(<Shell />)
