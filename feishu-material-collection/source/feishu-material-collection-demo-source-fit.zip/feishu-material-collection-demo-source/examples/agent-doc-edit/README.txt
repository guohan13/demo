只读依赖：feishu-material-collection 通过
import '../agent-doc-edit/agent-doc-edit.css'
引用本样式。完整 Creative 演示见上游 stageshow examples/agent-doc-edit。
