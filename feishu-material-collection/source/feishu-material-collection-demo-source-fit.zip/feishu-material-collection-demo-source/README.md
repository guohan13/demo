# Feishu 素材收集 — Stageshow 可运行源码包（viewport fit · t37u）

本 ZIP 为**完整可运行源码导出**（交互 demo：蓝色 kit 虚拟光标 + 克制涟漪，play once + Replay）。
**t37u：** portable / offline 根容器改为 **contain** scale-to-fit（min(1, vw/1180, vh/640)），944×630 等偏小窗口不再左右裁切导航与 AI rail。

离线单文件请用同批交付的 `feishu-material-collection-demo-fit.html`（新文件名，避免旧附件缓存）。

## 原始路径（工作机）

- 演示：`/home/box/agent-data/workflows/stageshow/examples/feishu-material-collection/`
- CSS 依赖：`examples/agent-doc-edit/agent-doc-edit.css`
- 共享 kit：`kit/`
- Stageshow 根：`/home/box/agent-data/workflows/stageshow/`

## 包内范围

含 package.json / package-lock.json / LICENSE、kit/、assets/、examples/feishu-material-collection/、examples/agent-doc-edit/、scripts/、references/、stills/。

**未包含：** node_modules/、密钥、浏览器用户数据、其他无关 examples、playground、teaching。

## 环境

- Node.js >= 20.19
- 可选：本机 Google Chrome（仅 scripts/film.mjs 截帧需要）

## 安装

```bash
unzip feishu-material-collection-demo-source-fit*.zip
cd feishu-material-collection-demo-source
npm ci
```

## 开发

```bash
npm run dev
```

默认：http://127.0.0.1:4613/portable.html

窗口缩放时 ResizeObserver 会重算 --fs-scale；kit drawnScale 保持 cursor/ghost/drop 对齐。

## Viewport fit（t37u）

- 设计舞台固定 1180×640；CSS --fs-scale = min(1, vw/1180, vh/640)（contain，非 cover）
- Film / window.__ssVerification 强制 scale=1
- 偏高窗口：沙色背景自然延展；产品窗口完整可见优先

## 构建

```bash
npm run build
```

## 光标

- cursor={{ style: 'arrow', ripple: true, idle: false }}
- --ss-cursor-ink: #3370ff

## 故事（约 15–16s，5 beats）

1. 空 composer 2. 多选 Docs 拖入 3. 导航 Messages 4. 拖会话卡片 5. 输入 prompt 停留
